import docx
import pandas as pd
from nltk.tokenize import word_tokenize
from nltk.probability import FreqDist
from nltk.corpus import stopwords

import nltk
nltk.download('punkt')
nltk.download('stopwords')

def preprocess_text(text):
    words = word_tokenize(text.lower())
    stop_words = set(stopwords.words('english'))
    words = [word for word in words if word.isalpha() and word not in stop_words]
    return words

def count_occurrences(doc, terms):
    doc_words = preprocess_text(doc)
    term_counts = FreqDist(word for word in doc_words if word in terms)
    return term_counts

def save_to_excel(results, excel_filename='linguistic_phenomena_counts.xlsx'):
    df = pd.DataFrame(results.items(), columns=['Phenomenon', 'Count'])
    df.to_excel(excel_filename, index=False)
    print(f"Counts saved to {excel_filename}")

def main(docx_filename):
    doc = docx.Document(docx_filename)
    full_text = []
    for para in doc.paragraphs:
        full_text.append(para.text)
    document_text = ' '.join(full_text)
    reiteration_terms = ['reiteration']
    synonyms_terms = ['synonyms', 'similar', 'concepts', 'interest', 'clarity']
    antonyms_terms = ['antonyms', 'opposite', 'contrasts']
    hyponyms_terms = ['hyponyms', 'specific', 'terms', 'general', 'category', 'depth', 'information']
    meronyms_terms = ['meronyms', 'part-whole', 'relationships', 'complexity']
    general_words_terms = ['general', 'words', 'broad', 'terms', 'context', 'conditions']
    reiteration_counts = count_occurrences(document_text, reiteration_terms)
    synonyms_counts = count_occurrences(document_text, synonyms_terms)
    antonyms_counts = count_occurrences(document_text, antonyms_terms)
    hyponyms_counts = count_occurrences(document_text, hyponyms_terms)
    meronyms_counts = count_occurrences(document_text, meronyms_terms)
    general_words_counts = count_occurrences(document_text, general_words_terms)
    results = {
        'Reiteration': sum(reiteration_counts.values()),
        'Synonyms': sum(synonyms_counts.values()),
        'Antonyms': sum(antonyms_counts.values()),
        'Hyponyms': sum(hyponyms_counts.values()),
        'Meronyms': sum(meronyms_counts.values()),
        'General Words': sum(general_words_counts.values())
    }

    save_to_excel(results)

if __name__ == "__main__":
    word_document_filename = "fact_sheets.docx"
    main(word_document_filename)
